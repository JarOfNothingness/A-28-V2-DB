-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2024 at 03:00 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grading management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_schedule`
--

CREATE TABLE `admin_schedule` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `type` enum('schedule','announcement') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_schedule`
--

INSERT INTO `admin_schedule` (`id`, `admin_id`, `title`, `description`, `start_datetime`, `end_datetime`, `type`) VALUES
(2, 10, '123', '123', '2024-08-28 16:29:00', '2024-08-28 23:29:00', 'schedule');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `content`, `created_at`) VALUES
(2, 'Foundation Week', 'Aug 29.30 - Sep 1,2,3,4', '2024-08-27 05:20:54');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `status` enum('Present','Absent','Late') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `class_records`
--

CREATE TABLE `class_records` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `written_exam` decimal(5,2) DEFAULT NULL,
  `performance_task` decimal(5,2) DEFAULT NULL,
  `quarterly_exam` decimal(5,2) DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `empt_table`
--

CREATE TABLE `empt_table` (
  `id` int(11) NOT NULL,
  `username` varchar(36) NOT NULL,
  `email` varchar(36) NOT NULL,
  `password` varchar(36) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `empt_table`
--

INSERT INTO `empt_table` (`id`, `username`, `email`, `password`) VALUES
(1, 'Gorlock', 'gorlock@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `fileserver_files`
--

CREATE TABLE `fileserver_files` (
  `file_id` int(11) NOT NULL,
  `folder_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fileserver_files`
--

INSERT INTO `fileserver_files` (`file_id`, `folder_id`, `file_name`, `file_path`, `uploaded_at`) VALUES
(1, 1, '1233333.png', 'uploads/1233333.png', '2024-08-28 14:44:40'),
(2, 1, 'Account Settings.png', 'uploads/Account Settings.png', '2024-08-28 17:02:56'),
(3, 4, 'Logo.png', 'uploads/Logo.png', '2024-08-28 17:14:34'),
(4, 3, '1233333 (1).png', 'uploads/1233333 (1).png', '2024-08-28 19:18:59');

-- --------------------------------------------------------

--
-- Table structure for table `fileserver_folders`
--

CREATE TABLE `fileserver_folders` (
  `folder_id` int(11) NOT NULL,
  `folder_name` varchar(255) NOT NULL,
  `folder_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fileserver_folders`
--

INSERT INTO `fileserver_folders` (`folder_id`, `folder_name`, `folder_password`) VALUES
(1, '123', '$2y$10$kM3Uvo0YeI3u7LLsvY9wL.xA8l6XHm3qdW/3ZGW5/fMtKFgjGCiDa'),
(2, 'System files', '$2y$10$VqZ6mU8ggmw7Fcgu2sCwceA4psumVh3VSaMIwy5i1HyU5RrjH60Xm'),
(3, 'Testing', '$2y$10$NU1NmxiQRjczSwqR6yO2PO/lYS3PvIYLCJjMythEPQ7OnekEuyPKm'),
(4, 'IDK', '$2y$10$cevbXVFOLeXXxe4bJuznHOJoCwdQUUFXKSAnSp0/MUwijDfcfwGDS'),
(5, '123', '$2y$10$Rh2r.5YTe78jyn.H2TW/RuiXyKsUi/WMgcrlFCFHt74sgB5By9PN6'),
(6, '123', '$2y$10$AEG1Th31M0fNMdQFgrYot.k5yqRaLKq7mlvCi24KD1EITh8M.B9OK');

-- --------------------------------------------------------

--
-- Table structure for table `final_grades`
--

CREATE TABLE `final_grades` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `form14_final_grades`
--

CREATE TABLE `form14_final_grades` (
  `form14Id` int(11) NOT NULL,
  `schoolName` varchar(255) NOT NULL,
  `learnerName` varchar(255) NOT NULL,
  `gradeLevel` varchar(10) NOT NULL,
  `section` varchar(50) NOT NULL,
  `schoolYear` varchar(9) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `firstQuarterGrade` int(11) DEFAULT NULL,
  `secondQuarterGrade` int(11) DEFAULT NULL,
  `thirdQuarterGrade` int(11) DEFAULT NULL,
  `fourthQuarterGrade` int(11) DEFAULT NULL,
  `finalGrade` int(11) DEFAULT NULL,
  `totalScore` int(11) DEFAULT NULL,
  `highestPossibleScore` int(11) DEFAULT NULL,
  `highestScore` int(11) DEFAULT NULL,
  `lowestScore` int(11) DEFAULT NULL,
  `averageMean` int(11) DEFAULT NULL,
  `mps` int(11) DEFAULT NULL,
  `numStudentsGetting75PL` int(11) DEFAULT NULL,
  `percentageOfStudentsGetting75PL` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `form137_card`
--

CREATE TABLE `form137_card` (
  `form137Id` int(11) NOT NULL,
  `learnerName` varchar(255) NOT NULL,
  `gradeLevel` varchar(10) NOT NULL,
  `section` varchar(50) NOT NULL,
  `schoolYear` varchar(9) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `teacherName` varchar(100) NOT NULL,
  `schoolId` int(11) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `written_exam` decimal(5,2) DEFAULT NULL,
  `performance_task` decimal(5,2) DEFAULT NULL,
  `quarterly_exam` decimal(5,2) DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pending_list`
--

CREATE TABLE `pending_list` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `final_grade` decimal(5,2) DEFAULT NULL,
  `form_2` varchar(255) DEFAULT NULL,
  `form_137` varchar(255) DEFAULT NULL,
  `form_14` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `alert_sent` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `teacher_id`, `title`, `description`, `start_time`, `end_time`, `alert_sent`) VALUES
(1, 4, 'Orientation', 'Teachers meeting', '2024-08-01 17:58:00', '2024-08-01 18:00:00', 0),
(2, 6, 'wdasdasdsasdasdas', 'asdasd', '2024-08-09 19:28:00', '2024-08-01 07:33:00', 0),
(5, 35, 'Science ', 'Class', '2024-08-22 09:00:00', '2024-08-22 10:00:00', 0),
(10, 10, 'Test', '1', '2024-08-25 13:49:00', '2024-08-25 20:50:00', 0),
(11, 12, '123', '123', '2024-08-07 15:58:00', '2024-08-28 21:58:00', 0),
(12, 12, '123', '123', '2024-08-28 15:59:00', '2024-08-28 15:04:00', 0),
(13, 12, '123', '123', '2024-08-28 16:02:00', '2024-09-05 16:02:00', 0),
(14, 12, '123', '123', '2024-08-28 16:04:00', '2024-08-28 16:04:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sf2_attendance_report`
--

CREATE TABLE `sf2_attendance_report` (
  `form2Id` int(11) NOT NULL,
  `schoolId` int(11) NOT NULL,
  `learnerName` varchar(255) NOT NULL,
  `gradeLevel` varchar(10) NOT NULL,
  `learnerAttendanceConversionTool` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `schoolYear` varchar(9) NOT NULL,
  `month` varchar(20) NOT NULL,
  `day_01` char(1) DEFAULT NULL,
  `day_02` char(1) DEFAULT NULL,
  `day_03` char(1) DEFAULT NULL,
  `day_04` char(1) DEFAULT NULL,
  `day_05` char(1) DEFAULT NULL,
  `day_06` char(1) DEFAULT NULL,
  `day_07` char(1) DEFAULT NULL,
  `day_08` char(1) DEFAULT NULL,
  `day_09` char(1) DEFAULT NULL,
  `day_10` char(1) DEFAULT NULL,
  `day_11` char(1) DEFAULT NULL,
  `day_12` char(1) DEFAULT NULL,
  `day_13` char(1) DEFAULT NULL,
  `day_14` char(1) DEFAULT NULL,
  `day_15` char(1) DEFAULT NULL,
  `day_16` char(1) DEFAULT NULL,
  `day_17` char(1) DEFAULT NULL,
  `day_18` char(1) DEFAULT NULL,
  `day_19` char(1) DEFAULT NULL,
  `day_20` char(1) DEFAULT NULL,
  `day_21` char(1) DEFAULT NULL,
  `day_22` char(1) DEFAULT NULL,
  `day_23` char(1) DEFAULT NULL,
  `day_24` char(1) DEFAULT NULL,
  `day_25` char(1) DEFAULT NULL,
  `day_26` char(1) DEFAULT NULL,
  `day_27` char(1) DEFAULT NULL,
  `day_28` char(1) DEFAULT NULL,
  `day_29` char(1) DEFAULT NULL,
  `day_30` char(1) DEFAULT NULL,
  `day_31` char(1) DEFAULT NULL,
  `total_present` int(11) DEFAULT NULL,
  `total_absent` int(11) DEFAULT NULL,
  `total_late` int(11) DEFAULT NULL,
  `total_excused` int(11) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sf2_attendance_report`
--

INSERT INTO `sf2_attendance_report` (`form2Id`, `schoolId`, `learnerName`, `gradeLevel`, `learnerAttendanceConversionTool`, `section`, `schoolYear`, `month`, `day_01`, `day_02`, `day_03`, `day_04`, `day_05`, `day_06`, `day_07`, `day_08`, `day_09`, `day_10`, `day_11`, `day_12`, `day_13`, `day_14`, `day_15`, `day_16`, `day_17`, `day_18`, `day_19`, `day_20`, `day_21`, `day_22`, `day_23`, `day_24`, `day_25`, `day_26`, `day_27`, `day_28`, `day_29`, `day_30`, `day_31`, `total_present`, `total_absent`, `total_late`, `total_excused`, `remarks`) VALUES
(20, 209766, 'Kiara', '7th', '', 'Section A', '2020', '2024-08', 'P', 'P', 'P', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 3, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `learners_name` varchar(255) DEFAULT NULL,
  `region` varchar(100) DEFAULT NULL,
  `division` varchar(100) DEFAULT NULL,
  `school_id` varchar(100) DEFAULT NULL,
  `school_year` varchar(20) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `section` varchar(36) NOT NULL,
  `grade` varchar(36) NOT NULL,
  `school_level` varchar(10) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `learners_name`, `region`, `division`, `school_id`, `school_year`, `gender`, `subject`, `section`, `grade`, `school_level`, `user_id`) VALUES
(20248077, 'Kiara', 'VII', 'CEBU', '209766', '2020', 'Female', 'English', 'Section A', '7th', 'JHS', NULL),
(20248087, 'Josh Lim', 'VII', 'CEBU', '207590', '2021', 'Male', 'Advanced Science', 'Section X', '11th', 'SHS', NULL),
(20248088, 'Test', 'VII', 'CEBU', '200361', '2020', 'Male', 'Advanced Math', 'Section Y', '12th', 'SHS', NULL),
(20248090, 'Gabriel', 'VII', 'CEBU', '208806', '2021', 'Male', 'Science', 'Section A', '10th', 'JHS', NULL),
(20248091, 'Degoma', 'VII', 'CEBU', '206784', '2020', 'Female', 'PE', 'Section B', '8th', 'JHS', NULL),
(20248092, 'Anna Special', 'VII', 'CEBU', '203170', '2020', 'Female', 'Economics', 'Section X', '11th', 'SHS', 0),
(20248096, 'Magic', 'VII', 'CEBU', '207443', '2024', 'Male', 'PE', 'Section Z', '12th', 'SHS', 0);

-- --------------------------------------------------------

--
-- Table structure for table `student_grades`
--

CREATE TABLE `student_grades` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `written_exam` float DEFAULT NULL,
  `performance_task` float DEFAULT NULL,
  `quarterly_exam` float DEFAULT NULL,
  `final_grade` float DEFAULT NULL,
  `highest_possible_score` decimal(5,2) DEFAULT NULL,
  `lowest_score` decimal(5,2) DEFAULT NULL,
  `average_mean` decimal(5,2) DEFAULT NULL,
  `mps` decimal(5,2) DEFAULT NULL,
  `students_75_percent` int(11) DEFAULT NULL,
  `percentage_75_percent` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_grades`
--

INSERT INTO `student_grades` (`id`, `student_id`, `subject_id`, `written_exam`, `performance_task`, `quarterly_exam`, `final_grade`, `highest_possible_score`, `lowest_score`, `average_mean`, `mps`, `students_75_percent`, `percentage_75_percent`) VALUES
(34, 20248077, 1, 92, 89, 88, 89.7, NULL, NULL, NULL, NULL, NULL, NULL),
(35, 20248090, 2, 89, 91, 89, 90, NULL, NULL, NULL, NULL, NULL, NULL),
(36, 20248096, 8, 30, 0, 0, 9, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student_subject`
--

CREATE TABLE `student_subject` (
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `description`, `student_id`) VALUES
(1, 'Mathematics', 'Math course description', NULL),
(2, 'English', 'English course description', NULL),
(3, 'Science', NULL, NULL),
(4, 'PE', NULL, NULL),
(5, 'History', NULL, NULL),
(6, 'Advanced Math', NULL, NULL),
(7, 'Advanced Science', NULL, NULL),
(8, 'PE', NULL, NULL),
(9, 'Economics', NULL, NULL),
(10, 'Philosophy', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userid` int(11) NOT NULL,
  `name` varchar(36) NOT NULL,
  `username` varchar(36) NOT NULL,
  `password` varchar(36) NOT NULL,
  `address` varchar(36) NOT NULL,
  `role` varchar(36) NOT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `confirm_password` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `name`, `username`, `password`, `address`, `role`, `gender`, `contact_number`, `email`, `confirm_password`, `status`) VALUES
(8, 'moses', 'mm', '123', 'moses@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(10, 'Anna', 'Anna', 'summer', 'Anna@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(11, 'Els', 'els', 'snowqueen', 'els@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(12, 'Jose', 'JN', '123', 'Jose@gmail.com', 'Admin', NULL, NULL, NULL, '', 'approved'),
(14, 'Jake Serotonin', 'jake', '123', 'jakeS@gmail.com', 'Teacher', NULL, NULL, NULL, '123', 'approved'),
(23, 'Kristine', 'Kristine', '123', 'Kristine@gmail.com', 'Teacher', NULL, NULL, NULL, '123', 'approved'),
(31, 'Faith', 'Fathima123', 'fathima123', 'Fathima@gmail.com', 'Teacher', NULL, NULL, NULL, 'fathima123', 'approved'),
(35, 'Moses Mae', 'mmae.123', 'moses@123', 'moses@gmail.com', 'Teacher', NULL, NULL, NULL, 'moses@123', 'approved'),
(36, 'Melvic', 'Melvicgreg123', 'melvicgregg123', 'melvicgregg@gmail.com', 'Teacher', NULL, NULL, NULL, 'melvicgregg123', 'approved'),
(38, 'Joanna', 'JoannaMary123', '$2y$10$5cgduyhT.KukV7ZaI2sqt.sz6FWoK', 'Joannababy@gmail.com', 'Teacher', NULL, NULL, NULL, 'Maryjoana123', 'approved'),
(39, 'Testing', 'testing12345', 'db7f58f20646ac82', 'testing@gmail.com', 'Teacher', NULL, NULL, NULL, '', ''),
(40, 'Testing', 'testing12345', '$2y$10$z1xcuhBrXRoQnWuIqQnRReeGIw3n2', 'testing@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(41, 'Testing', 'testing123', '$2y$10$xG6pU5X.YcwRR3ZBP7WKbON2VDi54', 'testing@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(42, 'Hope', 'Hope123', '93429c1de7d67c2a', 'Hope@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(43, 'Hope', 'Hope123', '592ce79a93a91444', 'Hope@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(44, 'Hope', 'hope123', 'ddcbe7df437d9d52', 'Hope@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(46, 'Hope', 'Hope123', '90bd3b8491ec233a', 'Hope@gmail123', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(47, 'Hope', 'Hope123', '0a5a7e5c095f9991', 'Hope@gmail123', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(48, 'Hope', 'Hope123', 'db37352e501b087f', 'Hope@gmail123', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(51, 'Joanna', 'joannabel', 'joannabel123', 'Joanna@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(53, 'Kid', 'Akidz123', '855361bf75b81bd4', 'Akid@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(58, 'Joel Caesar', 'Joel123', '4d4d554ac37e21cb', 'JoelC@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(59, 'Joel Caesar', 'Joel1234', '76fd7b01b8b833be', 'JoelC@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(61, 'Montana', 'montana123', '86dd09ece0e9bdb7', 'montana@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(65, 'Montana', 'montana123', '6ab10a4117e7f093', 'montana@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(66, 'Pleasework', 'pleasework123', '173861b3af42cc95', 'pleasework@work', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(68, 'Fathima', 'Fathima123', '$2y$10$97DydBvZK1UtABb9gvoaneGdZF2a/', 'fathima@gmail.com', 'Teacher', NULL, NULL, NULL, '', ''),
(69, 'Kratos', 'kratos123', '6f2d01b3323cfce3', 'kratos@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(71, 'Testing123', 'testing321', '0214fb9497e8a052', '123testing@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(72, 'Testing123', 'testing321', 'jordanclarkson123', '123testing@gmail.com', 'Teacher', NULL, NULL, NULL, '', ''),
(73, 'PeterLang', 'Peter123', 'petero', 'Peterlang@gmail.com', 'Teacher', NULL, NULL, NULL, '', ''),
(74, 'Test90', 'Test90', 'test', 'test90@g', 'Teacher', NULL, NULL, NULL, '', ''),
(75, 'TestFunction', 'TestF', 'a109feafc575157e', 'Testf@g', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(77, 'Tester', 'Tester', 'b0177c1643372daa', 'T@g', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(78, 'Larabel', 'larabel123', 'larabel123', 'larabel@gmail.com', 'Teacher', NULL, NULL, NULL, '', ''),
(79, 'Xamp', 'Xamp123', 'xamp123', 'xamp@gmail.com', 'Teacher', NULL, NULL, NULL, '', ''),
(80, 'Testing123', 'testing123', 'testing123', 'test@gmail.com', 'Teacher', NULL, NULL, NULL, '', ''),
(81, 'testing123', 'testing123', '288ddc136c23509c', 'testing@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(82, 'larabel123', 'larabel123', 'f6639d5901b15e8e', 'testlara@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(83, 'testing', 'testing981', '569f771afba64990', 'testing@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(84, 'testing', 'testing981', '26faab65e4b125e8', 'testing@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(85, 'Unknown', 'unknown123', '219edd1803d25e8f', 'unknown@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(86, 'hopeless', 'hopeless123', '27e87039533abf0f', 'hope@gmail.com', 'Teacher', NULL, NULL, NULL, '', 'approved'),
(87, 'Kyler', 'kyler123', '$2y$10$mFV9PrwbJnSdVS/Wx6hduuZgnfoVX', 'kyler@gmail.com', 'Teacher', NULL, NULL, NULL, '', ''),
(88, 'John', 'john123', '$2y$10$6III4ynfjhWatDEqyvqV.O7ltFyl3', 'john@gmail.com', 'Teacher', NULL, NULL, NULL, '', ''),
(91, 'Darla', 'Darla123', 'darla123', 'darla@gmail.com', 'Teacher', NULL, NULL, NULL, '', ''),
(92, '123', '123123123', '123', '123@123', 'Teacher', NULL, NULL, NULL, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `userfileserverfiles`
--

CREATE TABLE `userfileserverfiles` (
  `file_id` int(11) NOT NULL,
  `folder_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userfileserverfiles`
--

INSERT INTO `userfileserverfiles` (`file_id`, `folder_id`, `file_name`, `file_path`, `uploaded_at`) VALUES
(1, 1, 'Form 14.jpg', 'uploads/Form 14.jpg', '2024-08-28 09:02:41'),
(2, 1, 'Account Settings.png', 'uploads/Account Settings.png', '2024-08-28 09:10:34'),
(3, 1, '1233333.png', 'uploads/1233333.png', '2024-08-28 09:11:13'),
(4, 1, '1233333.zip', 'uploads/1233333.zip', '2024-08-28 09:12:46'),
(5, 2, 'Form 14.jpg', 'uploads/Form 14.jpg', '2024-08-28 09:14:10'),
(6, 3, '1233333 (1).png', 'uploads/1233333 (1).png', '2024-08-28 09:52:37'),
(9, 13, '456724193_885042150151321_5238812809017422679_n.jpg', 'uploads/456724193_885042150151321_5238812809017422679_n.jpg', '2024-08-28 10:16:56'),
(13, 2, '1233333 (1).png', 'uploads/1233333 (1).png', '2024-08-28 11:29:26');

-- --------------------------------------------------------

--
-- Table structure for table `userfileserverfolders`
--

CREATE TABLE `userfileserverfolders` (
  `folder_id` int(11) NOT NULL,
  `folder_name` varchar(255) NOT NULL,
  `folder_password` varchar(255) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userfileserverfolders`
--

INSERT INTO `userfileserverfolders` (`folder_id`, `folder_name`, `folder_password`, `userid`) VALUES
(1, 'Goods', '$2y$10$.xih6UQdMqRfD34H8aizqOAOxvGehuQ7C.cEmwWR5YZbogufoKOai', 0),
(2, '123', '$2y$10$GtBBd5sK8uKo4nCp4DaB4ejP7JOVtQS08MBn6rTpRG0vbO91UiFvC', 0),
(3, '321', '$2y$10$RMelRG50D8hIuPZYwvGu/.JWWVd1rFsAIF3IZUM0nuYRiMsOqC1yy', 0),
(4, '321', '$2y$10$GCJpzzxyvbQRDAm64ID7h.x3VPakIgQp0by4PGAlX9Cmi2SQG996W', 0),
(13, 'Antonio', '$2y$10$qVtfsJfguWIKtwiRqE0VGOI2LlD707b8856Ca1k99d/xVXN/myv4m', 10),
(14, 'Testing', '$2y$10$cnLK3WBVEDPJjwPRIxmNhux7Pyk5bb75EzmMY/Og9HNGIHvz4V6h2', 10),
(15, 'Degz', '$2y$10$9NszVMgM0.jyGzGsQfuIBuJ6TVNx4J96vLi.FHQooaaAcM8czBL6O', 8),
(16, '123', '$2y$10$1XRGH6BvvJTXdGyUF7bbeOc4ofR9DFIoaFR/mRS9JUByRwRNsSvO2', 12),
(18, '123', '$2y$10$hV8bn7H09BjcZHre1xvAzeHqQ84cu4W6ESsehUzHhTsWa1Zau1a7S', 10),
(19, '123', '$2y$10$tcENnGUeIgsrLEV0.oqOeOZKmNuF2GRLGUuzygKc3qGFw17P6xj5C', 8),
(20, '123', '$2y$10$9XFq4gaG6XFDEe8mKbNBpOrzXZTWYkmaZTkHd5t3D2Y4a5bdcA4v.', 10),
(21, '123', '$2y$10$MzHYF5VOkdKGHMPu6eHqReFzbdTZ7HzkWHuqMZ3DLwGuqYsDgBlru', 10),
(23, 'Delete', '$2y$10$FvXWgA.20gz.9kSgj9jXi.zZTLZpmfJ1VeM8Ly3N9kMmtD8AquWAe', 8),
(24, '123', '$2y$10$qE5iBpIHQqo/xMkLtRRPG.8tiYzY.kHGOK0zRbnfGaKuFkJNztbLW', 8),
(25, '123', '$2y$10$wHMGPZbJA1Ql6093k/pfX.r8fTTzKX1tjWHKoHl8Wvz7BEMX9gTYm', 12);

-- --------------------------------------------------------

--
-- Table structure for table `user_activity_log`
--

CREATE TABLE `user_activity_log` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_activity_log`
--

INSERT INTO `user_activity_log` (`id`, `username`, `action`, `timestamp`, `role`) VALUES
(1, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:04', NULL),
(2, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05', NULL),
(3, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05', NULL),
(4, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05', NULL),
(5, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:05', NULL),
(6, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:06', NULL),
(7, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:09', NULL),
(8, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:11', NULL),
(9, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:13', NULL),
(10, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:15', NULL),
(11, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:48:22', NULL),
(12, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:49:08', NULL),
(13, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:49:11', NULL),
(14, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:51:28', NULL),
(15, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:51:31', NULL),
(16, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:51:36', NULL),
(17, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:52:13', NULL),
(18, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:26', NULL),
(19, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:30', NULL),
(20, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:53', NULL),
(21, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:54:53', NULL),
(22, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:55:26', NULL),
(23, 'JN', 'Accessed Admin Homepage', '2024-08-20 08:57:59', NULL),
(24, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:01:18', NULL),
(25, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:01:34', NULL),
(26, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:03:20', NULL),
(27, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:03:44', NULL),
(28, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:05:33', NULL),
(29, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:08:58', NULL),
(30, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:09:03', NULL),
(31, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:18:02', NULL),
(32, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:21:16', NULL),
(33, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:21:23', NULL),
(34, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:21:33', NULL),
(35, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:23:55', NULL),
(36, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:37', NULL),
(37, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:39', NULL),
(38, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:42', NULL),
(39, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:44', NULL),
(40, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:25:59', NULL),
(41, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:26:05', NULL),
(42, 'admin', 'Accessed Admin Homepage', '2024-08-20 09:29:08', NULL),
(43, 'user1', 'Logged In', '2024-08-20 09:29:08', NULL),
(44, 'user2', 'Updated Profile', '2024-08-20 09:29:08', NULL),
(45, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:31:09', NULL),
(46, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:13', NULL),
(47, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:13', NULL),
(48, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:15', NULL),
(49, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:34:48', NULL),
(50, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:36:13', NULL),
(51, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:36:18', NULL),
(52, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:37:10', NULL),
(53, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:37:10', NULL),
(54, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:37:10', NULL),
(55, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:13', NULL),
(56, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:15', NULL),
(57, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:17', NULL),
(58, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:37', NULL),
(59, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:37', NULL),
(60, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:38:37', NULL),
(61, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:09', NULL),
(62, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:47', NULL),
(63, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:51', NULL),
(64, 'JN', 'Accessed Admin Homepage', '2024-08-20 09:39:53', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_schedule`
--
ALTER TABLE `admin_schedule`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `class_records`
--
ALTER TABLE `class_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `empt_table`
--
ALTER TABLE `empt_table`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fileserver_files`
--
ALTER TABLE `fileserver_files`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `folder_id` (`folder_id`);

--
-- Indexes for table `fileserver_folders`
--
ALTER TABLE `fileserver_folders`
  ADD PRIMARY KEY (`folder_id`);

--
-- Indexes for table `final_grades`
--
ALTER TABLE `final_grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `form14_final_grades`
--
ALTER TABLE `form14_final_grades`
  ADD PRIMARY KEY (`form14Id`);

--
-- Indexes for table `form137_card`
--
ALTER TABLE `form137_card`
  ADD PRIMARY KEY (`form137Id`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `pending_list`
--
ALTER TABLE `pending_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sf2_attendance_report`
--
ALTER TABLE `sf2_attendance_report`
  ADD PRIMARY KEY (`form2Id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_grades`
--
ALTER TABLE `student_grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `student_subject`
--
ALTER TABLE `student_subject`
  ADD PRIMARY KEY (`student_id`,`subject_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_student_subject` (`student_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `userfileserverfiles`
--
ALTER TABLE `userfileserverfiles`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `fk_folder` (`folder_id`);

--
-- Indexes for table `userfileserverfolders`
--
ALTER TABLE `userfileserverfolders`
  ADD PRIMARY KEY (`folder_id`);

--
-- Indexes for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_schedule`
--
ALTER TABLE `admin_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `class_records`
--
ALTER TABLE `class_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `empt_table`
--
ALTER TABLE `empt_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `fileserver_files`
--
ALTER TABLE `fileserver_files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `fileserver_folders`
--
ALTER TABLE `fileserver_folders`
  MODIFY `folder_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `final_grades`
--
ALTER TABLE `final_grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `form14_final_grades`
--
ALTER TABLE `form14_final_grades`
  MODIFY `form14Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `form137_card`
--
ALTER TABLE `form137_card`
  MODIFY `form137Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pending_list`
--
ALTER TABLE `pending_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `sf2_attendance_report`
--
ALTER TABLE `sf2_attendance_report`
  MODIFY `form2Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20248097;

--
-- AUTO_INCREMENT for table `student_grades`
--
ALTER TABLE `student_grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `userfileserverfiles`
--
ALTER TABLE `userfileserverfiles`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `userfileserverfolders`
--
ALTER TABLE `userfileserverfolders`
  MODIFY `folder_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `user_activity_log`
--
ALTER TABLE `user_activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_schedule`
--
ALTER TABLE `admin_schedule`
  ADD CONSTRAINT `admin_schedule_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `user` (`userid`) ON DELETE CASCADE;

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `class_records`
--
ALTER TABLE `class_records`
  ADD CONSTRAINT `class_records_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `fileserver_files`
--
ALTER TABLE `fileserver_files`
  ADD CONSTRAINT `fileserver_files_ibfk_1` FOREIGN KEY (`folder_id`) REFERENCES `fileserver_folders` (`folder_id`) ON DELETE CASCADE;

--
-- Constraints for table `final_grades`
--
ALTER TABLE `final_grades`
  ADD CONSTRAINT `final_grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `grades`
--
ALTER TABLE `grades`
  ADD CONSTRAINT `grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `student_grades`
--
ALTER TABLE `student_grades`
  ADD CONSTRAINT `student_grades_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  ADD CONSTRAINT `student_grades_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `student_subject`
--
ALTER TABLE `student_subject`
  ADD CONSTRAINT `student_subject_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `student_subject_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `fk_student_subject` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`);

--
-- Constraints for table `userfileserverfiles`
--
ALTER TABLE `userfileserverfiles`
  ADD CONSTRAINT `fk_folder` FOREIGN KEY (`folder_id`) REFERENCES `userfileserverfolders` (`folder_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `userfileserverfiles_ibfk_1` FOREIGN KEY (`folder_id`) REFERENCES `userfileserverfolders` (`folder_id`);

--
-- Constraints for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD CONSTRAINT `user_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`userid`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
